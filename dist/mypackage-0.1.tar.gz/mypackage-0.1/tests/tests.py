from mypackage import myModule
        